<!DOCTYPE html>
<?php include("funs.php"); ?>
<html>

   <head>
     <title>Admin Panel</title>
             <link rel = "icon" href =
             "images/logo.png"
             type = "image/x-icon">
             <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <link rel="stylesheet" href="css/adminpanelp.css">
        <link rel="stylesheet" href="css/adminpatients.css">

   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  </head>


   <body style="background: white;">



    <?php require_once "sidebar.php"; ?>


    <section id="admin_overview" >
      <div class="container">

        <div class="overviewH1">
         <div class ="container">
           <div class="card-body">
             <div class="overviewHCard" style="background:#202124;">
           <h3>Overview</h3>
             </div>
           </div>
         </div>
       </div>

       <div class="border_box" style="background: white">
        <div class="card-body"  >
          <div class="row admin_overview">
            <div class="col-md-4 text-center">
              <div class="row ">
                  <div class="col-md-2">
              <div class="vl" style="  border-left: 3px solid blue;"></div>
            </div>
              <div class="col-md-10 text-left">
               <h4>Current Guests</h4>
               <h6>total Guests: <?php get_guest_count (); ?></h6>

               <a href="viewguest.php">Go to details</a>
             </div>
           </div>
            </div>
            <div class="col-md-4 text-center">
              <div class="row ">
                  <div class="col-md-2 ">
              <div class="vl" style="  border-left: 3px solid green;"></div>
            </div>
              <div class="col-md-10 text-left">
            <h4>Hotel Rooms</h4>
            <h6>Total Rooms:<?php get_room_count (); ?></h6>
            <a href="viewroom.php">Go to details</a>
             </div>
           </div>
            </div>
            <div class="col-md-4 text-center">
             <div class="row ">
           <div class="col-md-2 ">
          <div class="vl" style="  border-left: 3px solid yellow;"></div>
           </div>
             <div class="col-md-10 text-left">
              <h4>Hotel Workers</h4>
              <h6>Total Workers: <?php get_worker_count (); ?></h6>
              <a href="viewworker.php">Go to details</a>
            </div>
          </div>
        </div>
            </div>
          </div>
        </div>
      </div>
  </section>
   </body>
   </html>
