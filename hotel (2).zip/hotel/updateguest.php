<!DOCTYPE html>
<?php include("funs.php"); ?>
<html>

   <head>
     <title>Clintical</title>
             <link rel = "icon" href =
             "images/logo.png"
             type = "image/x-icon">
             <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <link rel="stylesheet" href="css/sidebar.css">
      <link rel="stylesheet" href="css/sections.css">
     <link rel="stylesheet" href="css/adminpanelppp.css">
      <link rel="stylesheet" href="css/adminpanelp.css">
        <link rel="stylesheet" href="css/adminquarantine.css">
        <link rel="stylesheet" href="css/adminpatients.css">

   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>




  </head>


   <body>


         <?php require_once "navbar.php"; ?>

         <?php



         $con=mysqli_connect("localhost","root","","hotel");
         $getid=$_GET['id'];



        $query1="select * from guest where guest_id='$getid';";
        $result1=mysqli_query($con,$query1);

        $query2="select * from check_in_out where guest_id='$getid';";
        $result2=mysqli_query($con,$query2);

   while($row=mysqli_fetch_array($result1)){

              $id=$row['guest_id'];
              $fname=$row['first_name'];
              $lname=$row['last_name'];
              $address=$row['address'];
              $phone=$row['contact_number'];
              
}
while($row=mysqli_fetch_array($result2)){

              $sdate=$row['start_date'];
		          $edate=$row['end_date'];
}
            ?>



         <section id="addpatient" style="margin-top:60px;margin-bottom:40px;">
          <div class ="container">
            <h1>Update Guest</h1>
            <hr/>
         <div class="main" >

                   <div class="card-body" >

             <form class="form-group" action="funs.php" method="post">
               
               <input type="hidden" name="id" class="form-control" required value= "<?php echo $id ?>"><br>
               <label>First Name:</label><br>
               <input type="text" name="fname" class="form-control" required value= "<?php echo $fname ?>"><br>
               <label>Last Name:</label><br>
               <input type="text" name="lname" class="form-control" required value= "<?php echo $lname ?>"><br>
               <label>Address:</label><br>
               <input type="text" name="address" class="form-control" value= "<?php echo $address ?>"><br>
               <label>Contact Number:</label><br>
               <input type="text" name="phone" class="form-control" value= "<?php echo $phone ?>"><br>
               <label>Start Date:</label><br>
               <input type="date" name="sdate" class="form-control" value= "<?php echo $sdate ?>"><br>
               <label>End Date:</label><br>
               <input type="date" name="edate" class="form-control" value= "<?php echo $edate ?>"><br>
                 <input type="submit" class="btn btn-primary" name="update_guest" value="Update Guest">
             </form>
                 </div>
               </div>
         </div>
</div>

     </section>
