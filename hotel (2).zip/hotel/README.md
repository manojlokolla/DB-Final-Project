# 🐙 Covid-19 management-System. 
<a href="https://github.com/Abdullah-Sheikh"><img alt="views" title="Github views" src="https://komarev.com/ghpvc/?username=Abdullah-Sheikh&style=flat-square" width="125"/></a>[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.svg?v=103)](#) [![GitHub Forks](https://img.shields.io/github/forks/Abdullah-Sheikh/management-System.svg?style=social&label=Fork&maxAge=2592000)](https://www.github.com/Abdullah/management-System/fork)[![GitHub Issues](https://img.shields.io/github/issues/Abdullah-Sheikh/management-System.svg?style=flat&label=Issues&maxAge=2592000)](https://www.github.com/Abdullah-Sheikh/management-System/issues)[![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat&label=Contributions&colorA=red&colorB=black	)](#)





https://user-images.githubusercontent.com/62107887/118883408-a2fb7000-b90e-11eb-98b5-b3eeb5bd0296.mp4











## Description :

COVID - 19 (Corona Virus Disease) is a pandamic that has cause many lives to keep record we have made a covid management system that hospitals can use admin portal to manage in they need to have login id and password. For database we've used phpmyadmin and ms sql. 
Everyone in public can see required precautions and information for COVID 19 all at one point. 

   This is Web Application which is build in php and Mysql Database. Languages used in this apllication are: html, CSS, Javascript, Php and SQL. Group members are:
 1.  https://github.com/Abdullah-Sheikh 
 2.  https://github.com/Zyyffi 
 3.  https://github.com/saadiiz27

 
   You can also view the site at : https://abdullah-sheikh.github.io/management-System/#top
   
   ##### Note: 👆 the above link not provide actual site beacuse the database is not connected and it is hosted on Github pages.
## User:
      It can see the isolation and quarantine wards in the Country and we provide two interface :
   
   1. Table
   2. By Google ( For google we use Maps Api)
     
     They can also see the precautions of #Covid-19 virus.
    
## Admin:

     In Admin, there are four section:
  1. Patients 
  2. Doctors
  3. Isolation wards.
  4. Quarantine wards
   
 ### Patients:
         In patient section the Admin can see, update patient status, delete the patients.
	 
	 
 ### Doctors:
         In doctors section the Admin can see, update doctors info, delete the patients.
	 
### Isolation Wards:
         In Isolation Ward section the Admin can see, update isolation ward status, delete the ward.
	 
### Quarantine  Wards:
         In Quarantine  Ward section the Admin can see, update isolation ward status, delete the ward.
	 
	 
## Add Database file:
         import the database file (covid-19_dbms) in mysql.
	 
 ## 🤝 Consulting / Coaching
Stuck with some problem? Need help in solution email me : <b>f180243@nu.edu.pk</b>


## 👨‍💻 Technical Skills & Expertise
- Google IT Support Specialist.
- Development of  Mobile Applications (Android and Flutter).
- Web Developer (HTML,CSS,JS,Bootstrap,Angular)
- Wordpress Developer
- Cloud Computing, Angular Development and Firebase 🔥.

<hr>

## Contributions Welcome
[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](#)

If you find any bug in the code or have any improvements in mind then feel free to generate a pull request.


## License
[![MIT](https://img.shields.io/cocoapods/l/AFNetworking.svg?style=style&label=License&maxAge=2592000)](../master/LICENSE)            
	      


Feel free to Star or Fork it and make your changes , then make pull request.

We will appreciate your Changes and Review it 😄

<div align="center">
	<br>
	<br>
	<br>
	<br>
	<img src="https://enterprise.github.com/assets/spinners/octocat-spinner-128-26a44333917854c6794d55eac947b1277fced54f1f60c5df5d93431db8753bc5.gif" width="40" height="40">
	<p>Loading</p>
	<br>
	<br>
	<br>
	<br>
</div>
