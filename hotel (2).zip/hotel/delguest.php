<?php

$con=mysqli_connect("localhost","root","","hotel");
if($con)
{
	//echo"Connection OK";
}
else
{
	//echo"Connection failed";
}


$delid=$_GET['del'];
echo $delid;
$query="delete from guest where guest_id='$delid'";
$result=mysqli_query($con,$query);
if ($result)
 {
 echo"<script>alert('Data Deleted Successfully')</script>";
 echo"<script>window.open('viewguest.php')</script>";
} else {
 echo"<script>alert('Error ')</script>";

}
?>
