<!DOCTYPE html>
<html>

   <head>
     <title>Clinitical Login</title>
             <link rel = "icon" href ="images/logo.png"type = "image/x-icon">
  
  <link rel="stylesheet" href="css/style.css">

   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <style>
  
    body{
      background-image: url("login_background_img.jpg");
      background-color: #cccccc;
    }
    </style>
  </head>


   <body>

     <nav class="navbar navbar-expand-lg navbar-light bg-light">
       <a class="navbar-brand" href="#"><img src="images/logo.png">Royal Hotel</a>
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>
       
     </nav>
     </section>
     <section id="login">
      <div class ="container">

           <div class="container" style=" width:400px;margin-top:60px;opacity:0.7;">
              <div class="card">
              <div class="card-body text-center">
                  <img style="widht:40px;height: 100px; margin:10px;padding:10px;align:center;"src="images/logo.png" class="center">
                  <h2 style="color:black; align:center;">Admin Login</h2>

                  <form  class="form-group" action="adminpanel.php" method="post">
                    <label style="color:black;">Email:</label><br>
                    <input type="text" name="email" class="form-control" placefolder="enter email" required><br>
                    <label style="color:black;">Password:"</label><br>
                    <input type="password" name="password" class="form-control" placefolder="enter password" required><br>    
                    <input type="Submit" name="login_submit" class="btn btn-primary center">
		              </form>
              </div>
	          </div>
  	      </div>
		 </div>




	 </div>
    </section>


    <!------------footer-------------->

    <section id="footer">
       <div class ="container text-center">
       <p>&copy Copyright 2020 royalhotel.com </p>
     </div>
     </section>
   </body>
<html>