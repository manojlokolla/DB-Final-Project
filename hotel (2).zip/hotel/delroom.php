<?php

$con=mysqli_connect("localhost","root","","hotel");

$delid=$_GET['del'];
echo $delid;
$query="delete from room_type where room_type='$delid'";
$result=mysqli_query($con,$query);
if ($result)
 {
 echo"<script>alert('Data Deleted Successfully')</script>";
 echo"<script>window.open('viewroom.php')</script>";
} else {
 echo"<script>alert('Error ')</script>";

}
?>
