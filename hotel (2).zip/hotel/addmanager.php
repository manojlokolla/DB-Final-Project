<!DOCTYPE html>
<?php include("funs.php"); ?>
<html>

   <head>
     <title>Add Guests</title>
             <link rel = "icon" href =
             "images/logo.png"
             type = "image/x-icon">
             <meta charset="UTF-8">
      
       <meta name="viewport" content="width=device-width, initial-scale=1.0">


   <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


  </head>

   <body>

         <?php require_once "navbar.php"; ?>

         <section id="addroom" style="margin-top:60px;margin-bottom:40px;">
          <div class ="container">
            <h1>Enter New Manager</h1>
            <hr/>
         <div class="main" >

                   <div class="card-body" >

             <form class="form-group" action="funs.php" method="post">
               <label>Manager ID:</label><br>
               <input type="text" name="id" class="form-control"><br>
               <label>Manager Name</label><br>
               <input type="text" name="name" class="form-control"><br>
               <label>Manager Phone</label><br>
               <input type="text" name="phone" class="form-control"><br>
               <input type="submit" class="btn btn-primary" name="manager_submit" value="Add Manager">
             </form>
                 </div>
               </div>
         </div>
</div>

     </section>
