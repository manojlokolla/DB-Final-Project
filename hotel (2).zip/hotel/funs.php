<?php

$con=mysqli_connect("localhost","root","","hotel");
if($con)
{
	//echo"Connection OK";
}
else
{
	echo"Connection failed";
}

if(isset($_POST['bill_submit']))
{
	$id=$_POST['bid'];
	$amount=$_POST['bamount'];
	$date=$_POST['bdate'];

	$quary="insert into bill (bill_id,amount,date) Values ('$id','$amount','$date')";
	$result=mysqli_query($con,$quary);

	

	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
    	echo"<script>window.open('viewguest.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('Data not inserted Successfully')</script>";

	}
}

if(isset($_POST['manager_submit']))
{
	$mid=$_POST['id'];
	$mname=$_POST['name'];
	$mphone=$_POST['phone'];
		
	$quary="insert into manager (manager_id,name,number) Values ('$mid','$mname','$mphone')";
	$result=mysqli_query($con,$quary);


	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
    	echo"<script>window.open('addmanager.php','_self')</script>";
	}
	else
		echo"<script>alert('Data not updated Successfully')</script>";
}


if(isset($_POST['manager_update']))
{
	$mid=$_POST['id'];
	$mname=$_POST['name'];
	$mphone=$_POST['phone'];


	$quary=" UPDATE manager SET manager_id='$mid', name='$mname', number='$mphone'
     WHERE manager_id='$mid';";
	$result=mysqli_query($con,$quary);
	
	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
		echo"<script>window.open('viewmanager.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('Data is not updated Successfully')</script>";
	}
}


function get_manager_details ()
{
	global $con;
	$quary="select *from manager";
	$result=mysqli_query($con,$quary);
	while($row=mysqli_fetch_array($result))
	{
		$id=$row['manager_id'];
		$name=$row['name'];
		$number=$row['number'];
		echo"
		<tr>
			<td>$id</td>
			<td>$name</td>
			<td>$number</td>
			<td><a href='updatemanager.php?id=$row[manager_id]'>Update</a></td>
			<td><a href='delmanager.php?del=$row[manager_id]'>Delete</a></td>
		</tr>";
	}
}

function get_payment_details ()
{
	global $con;
	$quary="select *from  bill";
	$result=mysqli_query($con,$quary);
	while($row=mysqli_fetch_array($result))
	{
		$id=$row['bill_id'];
		$name=$row['amount'];
		$number=$row['date'];
		echo"
		<tr>
			<td>$id</td>
			<td>$name</td>
			<td>$number</td>
		</tr>";
	}
}

if(isset($_POST['worker_submit']))
{
	$wid=$_POST['id'];
	$wname=$_POST['name'];
	$wphone=$_POST['phone'];
		
	$quary="insert into worker (worker_id,name,number) Values ('$wid','$wname','$wphone')";
	$result=mysqli_query($con,$quary);


	if($result)
	{
		echo"Data saved Successfully";
    	echo"<script>window.open('addworker.php','_self')</script>";
	}
}



if(isset($_POST['update_worker']))
{
	$wid=$_POST['id'];
	$wname=$_POST['name'];
	$wphone=$_POST['phone'];

	

	$quary=" UPDATE worker SET worker_id='$wid', name='$wname', number='$wphone'
     WHERE worker_id='$wid';";
	$result=mysqli_query($con,$quary);
	
	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
		echo"<script>window.open('viewworker.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('Data is not updated Successfully')</script>";
	}
}


function get_worker_details ()
{
	global $con;
	$quary="select *from worker";
	$result=mysqli_query($con,$quary);
	while($row=mysqli_fetch_array($result))
	{
		$id=$row['worker_id'];
		$name=$row['name'];
		$number=$row['number'];
		echo"
		<tr>
			<td>$id</td>
			<td>$name</td>
			<td>$number</td>
			<td><a href='updateworker.php?id=$row[worker_id]'>Update</a></td>
			<td><a href='delworker.php?del=$row[worker_id]'>Delete</a></td>
		</tr>";
	}
}

if(isset($_POST['room_submit']))
{
	$id=$_POST['id'];
	$rtype=$_POST['rtype'];
	$rdesc=$_POST['rdesc'];
	$price=$_POST['price'];
		
	$quary="insert into room_type(room_id,room_type,description) Values ('$id','$rtype','$rdesc')";
	$result=mysqli_query($con,$quary);

	$quary="insert into price(room_id,price) Values ('$id','$price')";
	$result=mysqli_query($con,$quary);
	echo"Data saved Successfully";
    echo"<script>window.open('viewroom.php','_self')</script>";
	
}

function cal_bill()
{
	global $con;
}

function get_room_details ()
{
	global $con;
	$quary="select r.*,p.* from room_type r LEFT JOIN price p ON r.room_id=p.room_id ";
	$result=mysqli_query($con,$quary);
	while($row=mysqli_fetch_array($result))
	{
		$type=$row['room_type'];
		$desc=$row['description'];
		$price=$row['price'];
		echo"
		<tr>
			<td>$type</td>
			<td>$desc</td>
			<td>$price</td>
			<td><a href='updateroom.php?id=$row[room_type]'>Update</a></td>
			<td><a href='delroom.php?del=$row[room_type]'>Delete</a></td>
		</tr>";
	}
}


if(isset($_POST['update_room']))
{
	$rtype=$_POST['rtype'];
	$rdesc=$_POST['rdesc'];

	$quary=" UPDATE room_type SET room_type='$rtype', description='$rdesc'
     WHERE room_type='$rtype';";
	$result=mysqli_query($con,$quary);
	
	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
		echo"<script>window.open('viewroom.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('Data is not updated Successfully')</script>";
	}
}



if(isset($_POST['update_guest']))
{
	$id=$_POST['id'];
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$address=$_POST['address'];
	$phone=$_POST['phone'];
	$sdate=$_POST['sdate'];
	$edate=$_POST['edate'];

	$quary=" UPDATE guest SET guest_id='$id',first_name='$fname',last_name='$lname',address='$address',
    contact_number='$phone'
     WHERE guest_id='$id';";

	
	$result=mysqli_query($con,$quary);
	$quary=" UPDATE check_in_out SET start_date='$sdate',end_date='$edate'
		WHERE guest_id='$id';";

	$result=mysqli_query($con,$quary);
	if($result)
	{
		echo"<script>alert('Data updated Successfully')</script>";
		echo"<script>window.open('viewguest.php','_self')</script>";
	}
	else
	{
		echo"<script>alert('Data is not updated Successfully')</script>";
		echo"<script>window.open('updateguest.php','_self')</script>";
	}
}



if(isset($_POST['pat_submit']))
{
	$id=$_POST['id'];
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$address=$_POST['address'];
	$phone=$_POST['phone'];
	$sdate=$_POST['sdate'];
	$edate=$_POST['edate'];
		
	$quary="insert into guest(guest_id,first_name,last_name,address,
	contact_number) Values ('$id','$fname','$lname','$address','$phone')";
	$result=mysqli_query($con,$quary);

	$quary="insert into check_in_out(start_date, end_date, reservation_id, guest_id) 
	Values ('$sdate','$edate','$id','$id')";
	$result=mysqli_query($con,$quary);

	
	if($result)
	{
		echo"Data saved Successfully";
    echo"<script>window.open('viewroom.php','_self')</script>";
	}
}




function get_guest_details ()
{
	global $con;
	$quary="select *from guest g Inner JOIN check_in_out c ON g.guest_id=c.guest_id ";
	$result=mysqli_query($con,$quary);
	while($row=mysqli_fetch_array($result))
	{
		$id=$row['guest_id'];
		$fname=$row['first_name'];
		$lname=$row['last_name'];
		$address=$row['address'];
		$phone=$row['contact_number'];
		$sdate=$row['start_date'];
		$edate=$row['end_date'];
	
		echo"
		<tr>
			<td>$id</td>
			<td>$fname</td>
			<td>$lname</td>
			<td>$address</td>
			<td>$phone</td>
			<td>$sdate</td>
			<td>$edate</td>
			<td><a href='updateguest.php?id=$row[guest_id]'>Update</a></td>
			<td><a href='delguest.php?del=$row[guest_id]'>Delete</a></td>
		</tr>";
	}
}

function get_guest_count ()
{
	global $con;
	$quary="SELECT count(guest_id) AS total  FROM guest";
	$result=mysqli_query($con,$quary);
	$values=mysqli_fetch_assoc($result);
	$num_rows=$values['total'];
	echo $num_rows;
}

function get_room_count ()
{
	global $con;
	$quary="SELECT count(room_type) AS total  FROM room_type";
	$result=mysqli_query($con,$quary);
	$values=mysqli_fetch_assoc($result);
	$num_rows=$values['total'];
	echo $num_rows;
}

function get_worker_count ()
{
	global $con;
	$quary="SELECT count(worker_id) AS total  FROM worker";
	$result=mysqli_query($con,$quary);
	$values=mysqli_fetch_assoc($result);
	$num_rows=$values['total'];
	echo $num_rows;
}

?>
